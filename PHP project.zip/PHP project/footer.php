</br><footer class='bg-dark'>
    <div class="ft">
            <a href="home.php"><b>Home</b></a>
            <a href="product.php"><b>Books</b></a>
            <a href="register.php"><b>Register</b></a>
            <a href="contact.php"><b>Contact</b></a></br></br>
            <span class="text-light">&copy;The Book</span>
            <span class="logo-txt">Haven</span>
    </div>
</footer>
