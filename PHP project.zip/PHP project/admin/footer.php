</br><footer class='bg-dark'>
    <div class="ft">
            <a href="insert.php"><b>Insert Books</b></a>
            <a href="product.php"><b>Books</b></a>
            <a href="order.php"><b>Orders</b></a>
            <a href="feedback.php"><b>Feedbacks</b></a></br></br>
            <span class="text-light">&copy;The Book</span>
            <span class="logo-txt">Haven</span>
    </div>
</footer>
